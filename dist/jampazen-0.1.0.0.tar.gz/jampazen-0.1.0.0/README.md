# JampaZen

JampaZen je hra plná zenové meditace a vybuchujících nestvůr postavená na Glossu.

Chůze - WSAD
Střílení -myš
